
public class SistemaVeiculos {
    public static void main(String[] args) {
        
        Veiculo carro = new Carro("Toyota", "Corolla", 2022, 8.5);
        Veiculo moto = new Moto("Honda", "CB 500", 2021);
        Veiculo caminhao = new Caminhao("Volvo", "FH16", 2020);

        
        System.out.println("=== CARRO ===");
        carro.exibirDetalhes();
        carro.acelerar();

        System.out.println("\n=== MOTO ===");
        moto.exibirDetalhes();
        moto.acelerar();

        System.out.println("\n=== CAMINHÃO ===");
        caminhao.exibirDetalhes();
        caminhao.acelerar();
    }
}
